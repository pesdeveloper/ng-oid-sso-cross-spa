import { Router } from '@angular/router';
import { OidcSecurityService, OpenIdConfiguration, LoginResponse } from 'angular-auth-oidc-client';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import { InjectionToken, EnvironmentProviders, OnDestroy } from '@angular/core';

/** Nivel de log simple */
declare enum SimpleLogLevel {
    None = 0,
    Error = 1,
    Warn = 2,
    Info = 3,
    Debug = 4
}
/**
 * Modo de recuperación cuando:
 * - Hay cookie en IdP (ping OK)
 * - Pero checkAuth/isAuthenticated local da false
 */
type RecoverMode = 'none' | 'promptNone' | 'interactive';
interface SsoSessionGuardOptions {
    /** Namespace para sessionStorage keys */
    appNs: string;
    /** OidcSecurityService (inyectado en tu app) */
    oidc: OidcSecurityService;
    /**
     * Obtiene el authority actual desde config OIDC (recomendado).
     * Ejemplo:
     *   authority$: () => oidc.getConfiguration().pipe(take(1), map(c => (c as any).authority))
     */
    authority$: () => Observable<string>;
    /** Path del ping en el IdP (default: '/api/session/ping') */
    pingPath?: string;
    /** Agregar ?ts=Date.now() (default: true) */
    cacheBuster?: boolean;
    /** Mínimo intervalo entre pings (default: 5000ms) */
    minIntervalMs?: number;
    /** Solo ping si la SPA cree que está autenticada (default: false) */
    onlyWhenAuthenticated?: boolean;
    /**
     * Office365-like:
     * Si NO hay sesión IdP => authorize() interactivo 1 vez por pestaña.
     * (default: false)
     */
    forceLoginIfNoIdpSession?: boolean;
    /**
     * Si HAY cookie IdP pero no hay auth local => recuperar:
     * - 'promptNone' (default)
     * - 'interactive'
     * - 'none'
     */
    recoverMode?: RecoverMode;
    /**
     * Eventos que disparan revalidación.
     * Default: ['pageshow','visibilitychange','focus']
     */
    events?: Array<'pageshow' | 'focus' | 'visibilitychange'>;
    /** Prefijo de logs (default: 'SSO') */
    logPrefix?: string;
    /** Si no puedo leer cfg.logLevel, uso este (default: Debug) */
    defaultLogLevel?: SimpleLogLevel;
    /**
     * (Opcional) Antiforgery warm-up:
     * Llama una URL (ej: {authority}/antiforgery/token) con credentials
     * para que el IdP/Backend setee cookies/tokens necesarios.
     * - Best effort: ignora errores
     * - Se ejecuta una sola vez por instancia
     */
    antiforgery?: {
        enabled?: boolean;
        /** default: '/antiforgery/token' */
        path?: string;
        /**
         * default: 'beforePing'
         * Nota: aunque exista este flag, el guard garantiza orden:
         * si antiforgery.enabled => se ejecuta antes de cualquier ping en bootstrap/resume.
         */
        run?: 'beforePing' | 'beforeRecover' | 'bootstrap';
        /** Implementación concreta del loader (la arma el provider con HttpClient) */
        loader: (url: string) => Promise<void>;
    };
    /**
     * Lista blanca de prefijos de rutas permitidas para returnUrl.
     * Si no se define => se permite cualquier ruta (comportamiento actual).
     *
     * Ej:
     * ['/datos', '/clientes']
     */
    allowedReturnUrlPrefixes?: string[];
}
declare class SsoSessionGuardService {
    private started;
    private opts;
    private lastPingAt;
    private pingInFlight;
    private attached;
    private detachFns;
    private promptNoneOnceKey;
    private interactiveOnceKey;
    private logoutDisabledKey;
    private antiforgeryDone;
    private antiforgeryInFlight;
    private isResuming;
    private returnUrlKey;
    private returnUrlPendingKey;
    /**
     * Inicia el guard y engancha hooks.
     * Llamar 1 vez.
     */
    start(options: SsoSessionGuardOptions): void;
    /**
     * Opcional:
     * Hace 1 bootstrap: (antiforgery) -> ping IdP y luego:
     * - si no hay cookie => logoffLocal() y opcional login interactivo (office365)
     * - si hay cookie => no hace checkAuth automáticamente (por defecto)
     *
     * Si VOS querés enlazarlo con checkAuth, llamá esto en tu App.ts.
     */
    bootstrapAuthOnce(params?: {
        doCheckAuth?: boolean;
        router?: Router;
    }): Promise<void>;
    /**
     * Llamalo cuando el usuario hace logout desde ESTA app (botón logout).
     */
    markLogoutFromThisApp(): void;
    clearLogoutDisabledFlag(): void;
    private attachHooks;
    private isOidcCallbackUrl;
    /**
     * “Resume”: llamado por hooks.
     * Orden garantizado cuando hay ping:
     *   antiforgery (si enabled) -> ping
     */
    private onResume;
    clearPromptNoneOnceFlag(): void;
    private isLocallyAuthenticated;
    private handleNoIdpSession;
    private handleHasIdpButNoLocalAuth;
    private buildUrlFromAuthority;
    private ensureAntiforgeryOnce;
    private safePing;
    private getAuthorityOnce;
    private buildPingUrl;
    private isSafari;
    private isCrossSite;
    private canTryPromptNoneOnce;
    private clearPromptNoneOnce;
    private canTryInteractiveOnce;
    private clearInteractiveOnce;
    private isLogoutDisabled;
    private setLogoutDisabled;
    private clearLogoutDisabled;
    rememberReturnUrl(): void;
    private saveReturnUrlOnce;
    private clearReturnUrlPending;
    private consumeReturnUrl;
    tryRestoreAfterLogin(router: Router, opts?: {
        replaceUrl?: boolean;
    }): void;
    private isAllowedReturnPath;
    private getConfiguredLogLevel;
    private clampLogLevel;
    private logAt;
    private logDebug;
    private logWarn;
    private logError;
    static ɵfac: i0.ɵɵFactoryDeclaration<SsoSessionGuardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SsoSessionGuardService>;
}

/**
 * Config “para terceros”: mínima, clara, sin pensar demasiado.
 * - authority se deduce SIEMPRE desde la OpenIdConfiguration activa (oidc.getConfiguration()).
 */
interface SsoSessionGuardAppConfig {
    /** Namespace para keys en sessionStorage: 'bod', 'maspagos', etc. */
    appNs: string;
    /** (opcional) Path del ping en el IdP */
    pingPath?: string;
    /** (opcional) Cache buster ?ts=... */
    cacheBuster?: boolean;
    /** (opcional) Throttle entre pings */
    minIntervalMs?: number;
    /** (opcional) Solo ping si la SPA cree que está autenticada */
    onlyWhenAuthenticated?: boolean;
    /**
     * “Office365-like”
     * - true: si NO hay sesión en el IdP => authorize() (login interactivo) una vez por pestaña
     * - false: solo limpia local (logoffLocal) y deja a la app deslogueada
     */
    forceLoginIfNoIdpSession?: boolean;
    /**
     * Si HAY cookie IdP pero NO hay auth local:
     * - 'none': no recupera
     * - 'promptNone': authorize(prompt=none) una vez por pestaña (recomendado)
     * - 'interactive': authorize() una vez por pestaña
     */
    recoverMode?: RecoverMode;
    /** Eventos para revalidar (backbutton/alt-tab) */
    events?: Array<'pageshow' | 'focus' | 'visibilitychange'>;
    /** Prefijo de logs */
    logPrefix?: string;
    /** Nivel default si no se puede leer cfg.logLevel */
    defaultLogLevel?: SimpleLogLevel;
    antiforgery?: {
        enabled?: boolean;
        /** default '/antiforgery/token' */
        path?: string;
        /** default 'beforePing' */
        run?: 'beforePing' | 'beforeRecover' | 'bootstrap';
    };
    allowedReturnUrlPrefixes?: string[];
}
/** Token para inyectar la config */
declare const SSO_SESSION_GUARD_CONFIG: InjectionToken<SsoSessionGuardAppConfig>;
/**
 * Provider “único” para apps: instala el guard apenas levanta la app.
 * Importante: por defecto NO bloquea el bootstrap (no devuelve Promise/Observable).
 */
declare function provideSsoSessionGuard(config: SsoSessionGuardAppConfig): EnvironmentProviders;

interface AuthSessionState {
    isAuthenticated: boolean;
    config: OpenIdConfiguration | null;
    accessToken: string;
    accessPayload: any | null;
    idToken: string;
    idPayload: any | null;
    userInfo: any | null;
    userInfoLoadedAt: Date | null;
}

declare class AuthSessionFacade implements OnDestroy {
    private readonly oidc;
    private readonly guard;
    private readonly router;
    private readonly http;
    private subs;
    private started;
    private readonly _state$;
    readonly state$: Observable<AuthSessionState>;
    readonly onLogin$: Observable<undefined>;
    readonly onLogout$: Observable<undefined>;
    private readonly _logoutRequested$;
    readonly onLogoutRequested$: Observable<void>;
    bootstrap(): void;
    login(): void;
    logout(): void;
    refresh(): Observable<LoginResponse>;
    goUserProfile(): void;
    getAccessToken(): Observable<string>;
    refreshTokens(): void;
    refreshUserInfo(): void;
    clearUserInfo(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthSessionFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthSessionFacade>;
}

export { AuthSessionFacade, SSO_SESSION_GUARD_CONFIG, SimpleLogLevel, SsoSessionGuardService, provideSsoSessionGuard };
export type { AuthSessionState, RecoverMode, SsoSessionGuardAppConfig, SsoSessionGuardOptions };
