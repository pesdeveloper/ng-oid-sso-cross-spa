import { OidcSecurityService, OpenIdConfiguration, LoginResponse } from 'angular-auth-oidc-client';
import { Observable } from 'rxjs';
import * as _angular_core from '@angular/core';
import { InjectionToken, EnvironmentProviders, OnDestroy } from '@angular/core';

/** Nivel de log simple */
declare enum SimpleLogLevel {
    None = 0,
    Error = 1,
    Warn = 2,
    Info = 3,
    Debug = 4
}
/**
 * Modo de recuperación cuando:
 * - Hay cookie en IdP (ping OK o inconcluso)
 * - Pero checkAuth/isAuthenticated local da false
 */
type RecoverMode = 'none' | 'promptNone' | 'interactive';
interface SsoSessionGuardOptions {
    /** Namespace para sessionStorage keys */
    appNs: string;
    /** OidcSecurityService (inyectado en tu app) */
    oidc: OidcSecurityService;
    /** Obtiene el authority actual desde config OIDC */
    authority$: () => Observable<string>;
    /** Path del ping en el IdP (default: '/api/session/ping') */
    pingPath?: string;
    /** Agregar ?ts=Date.now() (default: true) */
    cacheBuster?: boolean;
    /** Mínimo intervalo entre pings (default: 5000ms) */
    minIntervalMs?: number;
    /** Solo ping si la SPA cree que está autenticada (default: false) */
    onlyWhenAuthenticated?: boolean;
    /** Office365-like: si NO hay sesión IdP => authorize() interactivo 1 vez por pestaña. (default false) */
    forceLoginIfNoIdpSession?: boolean;
    /** Recuperación si hay cookie IdP pero no auth local (default 'promptNone') */
    recoverMode?: RecoverMode;
    /** Eventos que disparan revalidación. Default: ['pageshow','visibilitychange','focus'] */
    events?: Array<'pageshow' | 'focus' | 'visibilitychange'>;
    /** Prefijo de logs (default 'SSO') */
    logPrefix?: string;
    /** Si no puedo leer cfg.logLevel, uso este (default Debug) */
    defaultLogLevel?: SimpleLogLevel;
    /** Antiforgery warm-up (best effort) */
    antiforgery?: {
        enabled?: boolean;
        path?: string;
        run?: 'beforePing' | 'beforeRecover' | 'bootstrap';
        loader: (url: string) => Promise<void>;
    };
    /** ✅ Deep-links permitidos (prefijos). Ej: ['/datos','/checkout'] */
    allowedReturnUrlPrefixes?: string[];
    /** ✅ Paths a ignorar SIEMPRE (además de callbacks OIDC). Ej: ['/logout','/signin-oidc'] */
    ignoredReturnUrlPrefixes?: string[];
}
declare class SsoSessionGuardService {
    private started;
    private opts;
    private lastPingAt;
    private pingInFlight;
    private attached;
    private detachFns;
    private promptNoneOnceKey;
    private interactiveOnceKey;
    private logoutDisabledKey;
    private antiforgeryDone;
    private antiforgeryInFlight;
    private isResuming;
    start(options: SsoSessionGuardOptions): void;
    /**
     * ✅ Verificación inicial "de verdad" al entrar a la app.
     * - antiforgery (si enabled) -> ping -> si no IdP => logoffLocal
     * - si doCheckAuth: checkAuth y, si hay cookie IdP pero no auth local => recover según recoverMode
     */
    bootstrapAuthOnce(params?: {
        doCheckAuth?: boolean;
    }): Promise<void>;
    /** Llamalo cuando el usuario hace logout desde ESTA app */
    markLogoutFromThisApp(): void;
    clearLogoutDisabledFlag(): void;
    getReturnUrlKey(): string;
    setReturnUrl(url: string, opts?: {
        overwrite?: boolean;
    }): void;
    popReturnUrl(): string | null;
    private attachHooks;
    private isOidcCallbackUrl;
    private onResume;
    private isLocallyAuthenticated;
    private handleNoIdpSession;
    private handleHasIdpButNoLocalAuth;
    private buildUrlFromAuthority;
    private ensureAntiforgeryOnce;
    private safePing;
    private getAuthorityOnce;
    private buildPingUrl;
    private isSafari;
    private isCrossSite;
    private captureReturnUrlIfNeeded;
    private canTryPromptNoneOnce;
    private clearPromptNoneOnce;
    private canTryInteractiveOnce;
    private clearInteractiveOnce;
    private isLogoutDisabled;
    private setLogoutDisabled;
    private clearLogoutDisabled;
    private normalizePath;
    private isPrefixMatch;
    private isAssetPath;
    private isReturnUrlAllowed;
    private getConfiguredLogLevel;
    private clampLogLevel;
    private logAt;
    private logDebug;
    private logWarn;
    private logError;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SsoSessionGuardService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<SsoSessionGuardService>;
}

/**
 * Config “para terceros”: mínima, clara, sin pensar demasiado.
 * - authority se deduce SIEMPRE desde la OpenIdConfiguration activa (oidc.getConfiguration()).
 */
interface SsoSessionGuardAppConfig {
    /** Namespace para keys en sessionStorage: 'bod', 'maspagos', etc. */
    appNs: string;
    /** (opcional) Path del ping en el IdP */
    pingPath?: string;
    /** (opcional) Cache buster ?ts=... */
    cacheBuster?: boolean;
    /** (opcional) Throttle entre pings */
    minIntervalMs?: number;
    /** (opcional) Solo ping si la SPA cree que está autenticada */
    onlyWhenAuthenticated?: boolean;
    /**
     * “Office365-like”
     * - true: si NO hay sesión en el IdP => authorize() (login interactivo) una vez por pestaña
     * - false: solo limpia local (logoffLocal) y deja a la app deslogueada
     */
    forceLoginIfNoIdpSession?: boolean;
    /**
     * Si HAY cookie IdP pero NO hay auth local:
     * - 'none': no recupera
     * - 'promptNone': authorize(prompt=none) una vez por pestaña (recomendado)
     * - 'interactive': authorize() una vez por pestaña
     */
    recoverMode?: RecoverMode;
    /** Eventos para revalidar (backbutton/alt-tab) */
    events?: Array<'pageshow' | 'focus' | 'visibilitychange'>;
    /** Prefijo de logs */
    logPrefix?: string;
    /** Nivel default si no se puede leer cfg.logLevel */
    defaultLogLevel?: SimpleLogLevel;
    /** Antiforgery warm-up (best effort) */
    antiforgery?: {
        enabled?: boolean;
        /** default '/antiforgery/token' */
        path?: string;
        /** default 'beforePing' */
        run?: 'beforePing' | 'beforeRecover' | 'bootstrap';
    };
    /**
     * ✅ OPCIONAL: si querés que el provider dispare el bootstrapAuthOnce() automáticamente.
     * Default: false (recomendado si tu app ya lo hace en el Facade).
     *
     * Importante: NO bloquea el arranque (fire-and-forget).
     */
    autoBootstrap?: boolean;
    /**
     * Si autoBootstrap=true:
     * - true: llama bootstrapAuthOnce({ doCheckAuth: true })
     * - false: llama bootstrapAuthOnce({ doCheckAuth: false })
     *
     * Default: true
     */
    autoBootstrapDoCheckAuth?: boolean;
    allowedReturnUrlPrefixes?: string[];
    ignoredReturnUrlPrefixes?: string[];
}
/** Token para inyectar la config */
declare const SSO_SESSION_GUARD_CONFIG: InjectionToken<SsoSessionGuardAppConfig>;
/**
 * Provider “único” para apps: instala el guard apenas levanta la app.
 * Importante: por defecto NO bloquea el bootstrap.
 */
declare function provideSsoSessionGuard(config: SsoSessionGuardAppConfig): EnvironmentProviders;

interface AuthSessionState {
    isAuthenticated: boolean;
    config: OpenIdConfiguration | null;
    accessToken: string;
    accessPayload: any | null;
    idToken: string;
    idPayload: any | null;
    userInfo: any | null;
    userInfoLoadedAt: Date | null;
}

declare class AuthSessionFacade implements OnDestroy {
    private readonly oidc;
    private readonly guard;
    private readonly http;
    private readonly events;
    private readonly router;
    private _bootstrapPromise;
    private _bootstrapped;
    private subs;
    private started;
    private readonly _state$;
    readonly state$: Observable<AuthSessionState>;
    private readonly _logoutRequested$;
    readonly onLogoutRequested$: Observable<void>;
    private _pendingReturnUrl;
    readonly onLogin$: Observable<undefined>;
    readonly onLogout$: Observable<undefined>;
    readonly state: _angular_core.Signal<AuthSessionState>;
    readonly isAuthenticated: _angular_core.Signal<boolean>;
    readonly config: _angular_core.Signal<OpenIdConfiguration | null>;
    readonly accessToken: _angular_core.Signal<string>;
    readonly accessPayload: _angular_core.Signal<any>;
    readonly idToken: _angular_core.Signal<string>;
    readonly idPayload: _angular_core.Signal<any>;
    readonly userInfo: _angular_core.Signal<any>;
    readonly userInfoLoadedAt: _angular_core.Signal<Date | null>;
    private readonly _refreshing;
    readonly refreshing: _angular_core.Signal<boolean>;
    readonly clientLabel: _angular_core.Signal<string>;
    checkAuthOnce(): Promise<boolean>;
    bootstrap(): void;
    bootstrapOnce(): Promise<void>;
    private setupDeepLinkRestore;
    private tryNavigatePendingReturnUrl;
    private computeClientLabelFromState;
    login(): void;
    logout(): void;
    refresh(): Observable<LoginResponse>;
    goUserProfile(): void;
    getAccessToken(): Observable<string>;
    refreshTokens(): void;
    refreshUserInfo(): void;
    clearUserInfo(): void;
    private patchState;
    private clearTokensAndUserInfo;
    private resetAuthState;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AuthSessionFacade, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<AuthSessionFacade>;
}

export { AuthSessionFacade, SSO_SESSION_GUARD_CONFIG, SimpleLogLevel, SsoSessionGuardService, provideSsoSessionGuard };
export type { AuthSessionState, RecoverMode, SsoSessionGuardAppConfig, SsoSessionGuardOptions };
