import * as i0 from '@angular/core';
import { Injectable, InjectionToken, makeEnvironmentProviders, provideAppInitializer, inject } from '@angular/core';
import { firstValueFrom, map, of, take as take$1, BehaviorSubject, Subject, forkJoin } from 'rxjs';
import { take, catchError, map as map$1, distinctUntilChanged, pairwise, filter, shareReplay, switchMap } from 'rxjs/operators';
import { OidcSecurityService } from 'angular-auth-oidc-client';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';

// sso-session-guard.service.ts
//
// Guard “plug-and-play” para SPAs Angular que usan angular-auth-oidc-client.
// Objetivo:
// - Revalidar si existe sesión REAL en el IdP (cookie) cuando la SPA “vuelve” (BFCache/backbutton, alt-tab, focus, etc.)
// - Si la cookie IdP NO está => limpiar estado local (logoffLocal) para evitar “falsos autenticados”.
// - Opcional “modo Office365”: si no hay sesión en IdP, disparar login interactivo 1 vez por pestaña.
// - Opcional: si HAY cookie IdP pero NO hay auth local, intentar recuperar con prompt=none (una sola vez por pestaña).
//
// NOTAS IMPORTANTES
// - No usa LoggerService (no exportable). En su lugar, intenta leer logLevel desde getConfiguration().
// - NO llama checkAuth automáticamente salvo que vos lo pidas (para no interferir con tu App.ts), salvo
//   en isLocallyAuthenticated() que es explícito (ver opts.onlyWhenAuthenticated).
// - Throttle + inFlight para evitar spam.
//
// Requisitos:
// - En el IdP debe existir GET {authority}/api/session/ping que devuelva:
//     200 => hay sesión (cookie válida)
//     401 => no hay sesión
// - CORS del IdP debe permitir credentials desde tus SPAs.
//
// Integración recomendada:
// - Usar provideSsoSessionGuard(...) (providers) para auto-start.
// - O manual: inyectás SsoSessionGuardService y llamás start(opts) en App.ngOnInit().
// -----------------------------
// Tipos y enums públicos
// -----------------------------
/** Nivel de log simple */
var SimpleLogLevel;
(function (SimpleLogLevel) {
    SimpleLogLevel[SimpleLogLevel["None"] = 0] = "None";
    SimpleLogLevel[SimpleLogLevel["Error"] = 1] = "Error";
    SimpleLogLevel[SimpleLogLevel["Warn"] = 2] = "Warn";
    SimpleLogLevel[SimpleLogLevel["Info"] = 3] = "Info";
    SimpleLogLevel[SimpleLogLevel["Debug"] = 4] = "Debug";
})(SimpleLogLevel || (SimpleLogLevel = {}));
// -----------------------------
// Service
// -----------------------------
class SsoSessionGuardService {
    started = false;
    // Estado interno
    opts;
    lastPingAt = 0;
    pingInFlight = false;
    attached = false;
    detachFns = [];
    // Keys (sessionStorage)
    promptNoneOnceKey = '';
    interactiveOnceKey = '';
    logoutDisabledKey = '';
    antiforgeryDone = false;
    antiforgeryInFlight = false;
    isResuming = false; // mutex simple
    returnUrlKey = '';
    returnUrlPendingKey = '';
    /**
     * Inicia el guard y engancha hooks.
     * Llamar 1 vez.
     */
    start(options) {
        if (this.started)
            return;
        this.started = true;
        // Defaults
        const pingPath = options.pingPath ?? '/api/session/ping';
        const cacheBuster = options.cacheBuster ?? true;
        const minIntervalMs = options.minIntervalMs ?? 5000;
        const onlyWhenAuthenticated = options.onlyWhenAuthenticated ?? false;
        const forceLoginIfNoIdpSession = options.forceLoginIfNoIdpSession ?? false;
        const recoverMode = options.recoverMode ?? 'promptNone';
        const events = options.events ?? ['pageshow', 'visibilitychange', 'focus'];
        const logPrefix = options.logPrefix ?? 'SSO';
        const defaultLogLevel = options.defaultLogLevel ?? SimpleLogLevel.Debug;
        this.opts = {
            ...options,
            pingPath,
            cacheBuster,
            minIntervalMs,
            onlyWhenAuthenticated,
            forceLoginIfNoIdpSession,
            recoverMode,
            events,
            logPrefix,
            defaultLogLevel,
        };
        // SessionStorage keys namespaced
        this.promptNoneOnceKey = `${this.opts.appNs}:oidc:promptnone:once`;
        this.interactiveOnceKey = `${this.opts.appNs}:oidc:interactive:once`;
        this.logoutDisabledKey = `${this.opts.appNs}:oidc:recover:disabled`;
        this.returnUrlKey = `${this.opts.appNs}:oidc:returnUrl`;
        this.returnUrlPendingKey = `${this.opts.appNs}:oidc:returnUrl:pending`;
        this.logDebug(`antiforgery enabled=${!!this.opts.antiforgery?.enabled} run=${this.opts.antiforgery?.run ?? 'beforePing'} path=${this.opts.antiforgery?.path ?? ''}`);
        this.attachHooks();
    }
    /**
     * Opcional:
     * Hace 1 bootstrap: (antiforgery) -> ping IdP y luego:
     * - si no hay cookie => logoffLocal() y opcional login interactivo (office365)
     * - si hay cookie => no hace checkAuth automáticamente (por defecto)
     *
     * Si VOS querés enlazarlo con checkAuth, llamá esto en tu App.ts.
     */
    async bootstrapAuthOnce(params) {
        const doCheckAuth = params?.doCheckAuth ?? false;
        // ✅ GARANTÍA: si antiforgery.enabled => SIEMPRE antes del ping en bootstrap
        if (this.opts.antiforgery?.enabled) {
            await this.ensureAntiforgeryOnce('bootstrap');
        }
        const ping = await this.safePing('bootstrap');
        if (ping === false) {
            await this.handleNoIdpSession('bootstrap');
            return;
        }
        if (doCheckAuth) {
            const resp = await firstValueFrom(this.opts.oidc.checkAuth().pipe(take(1)));
            this.logDebug(`bootstrap: checkAuth isAuthenticated=${resp?.isAuthenticated}`);
            // ✅ CLAVE: si venís del callback, deferir restore para que NO lo pise el oidc-client
            if (resp?.isAuthenticated && params?.router) {
                const router = params?.router;
                setTimeout(() => this.tryRestoreAfterLogin(router), 0);
            }
            if (!resp?.isAuthenticated) {
                // ✅ ping es true | null acá, ambos habilitan recover
                await this.handleHasIdpButNoLocalAuth('bootstrap');
            }
        }
    }
    /**
     * Llamalo cuando el usuario hace logout desde ESTA app (botón logout).
     */
    markLogoutFromThisApp() {
        this.setLogoutDisabled();
        this.clearPromptNoneOnce();
        this.clearInteractiveOnce();
        // ✅ limpieza de deep-link pendiente
        this.clearReturnUrlPending();
    }
    clearLogoutDisabledFlag() {
        this.clearLogoutDisabled();
    }
    // -----------------------------
    // Hooks (resume / BFCache)
    // -----------------------------
    attachHooks() {
        if (this.attached)
            return;
        this.attached = true;
        const { events } = this.opts;
        if (events.includes('pageshow')) {
            const fn = (ev) => {
                const persisted = ev?.persisted === true;
                // ✅ solo BFCache/back-forward (persisted=true)
                if (!persisted) {
                    this.logDebug(`pageshow ignored (persisted=false)`);
                    return;
                }
                this.onResume(`pageshow persisted=true`);
            };
            window.addEventListener('pageshow', fn);
            this.detachFns.push(() => window.removeEventListener('pageshow', fn));
        }
        if (events.includes('visibilitychange')) {
            const fn = () => {
                if (document.visibilityState === 'visible') {
                    this.onResume('visibilitychange visible');
                }
            };
            document.addEventListener('visibilitychange', fn);
            this.detachFns.push(() => document.removeEventListener('visibilitychange', fn));
        }
        if (events.includes('focus')) {
            const fn = () => this.onResume('focus');
            window.addEventListener('focus', fn);
            this.detachFns.push(() => window.removeEventListener('focus', fn));
        }
        this.logDebug(`hooks attached: ${events.join(', ')}`);
    }
    // -----------------------------
    // Lógica principal
    // -----------------------------
    isOidcCallbackUrl(url) {
        // Detecta callback típico OIDC:
        // - success: ?code=...&state=...
        // - error:   ?error=...&state=...
        // - extras: iss, session_state
        try {
            const u = new URL(url, window.location.origin);
            const p = u.searchParams;
            return p.has('code') || p.has('state') || p.has('error') || p.has('iss') || p.has('session_state');
        }
        catch {
            return /[?&](code|state|error|iss|session_state)=/i.test(url);
        }
    }
    /**
     * “Resume”: llamado por hooks.
     * Orden garantizado cuando hay ping:
     *   antiforgery (si enabled) -> ping
     */
    async onResume(reason) {
        if (!this.started)
            return;
        const url = window.location.href;
        // 1) callback => NO tocar nada
        if (this.isOidcCallbackUrl(url)) {
            this.logDebug(`onResume(${reason}) ignored: OIDC callback URL`);
            return;
        }
        // 2) logout desde esta app => NO tocar nada
        if (this.isLogoutDisabled()) {
            this.logDebug(`resume ignored (logoutDisabled=true). reason=${reason}`);
            return;
        }
        // 3) mutex
        if (this.isResuming) {
            this.logDebug(`onResume(${reason}) ignored: already running`);
            return;
        }
        this.isResuming = true;
        try {
            // 4) onlyWhenAuthenticated (soft): si no hay token local, no ping
            if (this.opts.onlyWhenAuthenticated) {
                let token = '';
                try {
                    token = await firstValueFrom(this.opts.oidc.getAccessToken().pipe(take(1)));
                }
                catch {
                    token = '';
                }
                if (!token) {
                    this.logDebug(`resume ignored (no accessToken). reason=${reason}`);
                    return;
                }
            }
            // 5) throttle (antes de hacer requests)
            const now = Date.now();
            if (now - this.lastPingAt < this.opts.minIntervalMs) {
                this.logDebug(`resume throttled (${now - this.lastPingAt}ms < ${this.opts.minIntervalMs}ms). reason=${reason}`);
                return;
            }
            // 6) in-flight
            if (this.pingInFlight) {
                this.logDebug(`resume ignored (pingInFlight=true). reason=${reason}`);
                return;
            }
            this.lastPingAt = now;
            this.pingInFlight = true;
            try {
                // ✅ GARANTÍA: si antiforgery.enabled => SIEMPRE antes del ping en resume
                if (this.opts.antiforgery?.enabled) {
                    await this.ensureAntiforgeryOnce(`resume:${reason}`);
                }
                this.logDebug(`resume -> ping IdP session... reason=${reason}`);
                const ping = await this.safePing(`resume:${reason}`);
                this.logDebug(`resume ping result=${ping} (true=hasIdp, false=noIdp, null=unknown)`);
                if (ping === false) {
                    await this.handleNoIdpSession(`resume:${reason}`);
                    return;
                }
                // local auth roto?
                const isLocalAuth = await this.isLocallyAuthenticated();
                this.logDebug(`resume local isAuthenticated=${isLocalAuth}`);
                if (!isLocalAuth) {
                    await this.handleHasIdpButNoLocalAuth(`resume:${reason}`);
                }
                else {
                    // Si se autenticó, limpiá flags para permitir futuros recover
                    this.clearPromptNoneOnce();
                    this.clearInteractiveOnce();
                    this.clearLogoutDisabled();
                }
            }
            finally {
                this.pingInFlight = false;
            }
        }
        catch (e) {
            this.logWarn(`resume failed (ignored). reason=${reason}`, e);
        }
        finally {
            this.isResuming = false;
        }
    }
    clearPromptNoneOnceFlag() {
        this.clearPromptNoneOnce();
    }
    async isLocallyAuthenticated() {
        try {
            const resp = await firstValueFrom(this.opts.oidc.checkAuth().pipe(take(1)));
            return !!resp?.isAuthenticated;
        }
        catch {
            return false;
        }
    }
    async handleNoIdpSession(context) {
        this.logWarn(`IdP session missing -> logoffLocal(). ctx=${context}`);
        try {
            this.opts.oidc.logoffLocal();
        }
        catch (e) {
            this.logWarn(`logoffLocal failed (ignored). ctx=${context}`, e);
        }
        // refrescar estado (BFCache)
        try {
            const resp = await firstValueFrom(this.opts.oidc.checkAuth().pipe(take(1)));
            this.logDebug(`after logoffLocal: checkAuth isAuthenticated=${resp?.isAuthenticated} ctx=${context}`);
        }
        catch (e) {
            this.logWarn(`after logoffLocal: checkAuth failed (ignored). ctx=${context}`, e);
        }
        if (this.opts.forceLoginIfNoIdpSession) {
            const can = this.canTryInteractiveOnce();
            this.logDebug(`office365-like: forceLoginIfNoIdpSession=true canInteractive=${can} ctx=${context}`);
            if (can) {
                try {
                    this.saveReturnUrlOnce();
                    this.opts.oidc.authorize();
                }
                catch (e) {
                    this.logError(`authorize() failed. ctx=${context}`, e);
                }
            }
        }
    }
    async handleHasIdpButNoLocalAuth(context) {
        const mode = this.opts.recoverMode;
        if (mode === 'none') {
            this.logDebug(`recoverMode=none (no action). ctx=${context}`);
            return;
        }
        if (mode === 'promptNone') {
            const can = this.canTryPromptNoneOnce();
            this.logDebug(`recoverMode=promptNone canTry=${can} ctx=${context}`);
            if (!can)
                return;
            // Si querés específicamente antes de recover (por si no hubo resume/bootstrap previo)
            if (this.opts.antiforgery?.enabled && (this.opts.antiforgery.run ?? 'beforePing') === 'beforeRecover') {
                await this.ensureAntiforgeryOnce(`recover:${context}`);
            }
            try {
                this.saveReturnUrlOnce();
                this.opts.oidc.authorize(undefined, { customParams: { prompt: 'none' } });
            }
            catch (e) {
                this.logError(`authorize(prompt=none) failed. ctx=${context}`, e);
            }
            return;
        }
        if (mode === 'interactive') {
            const can = this.canTryInteractiveOnce();
            this.logDebug(`recoverMode=interactive canTry=${can} ctx=${context}`);
            if (!can)
                return;
            try {
                this.saveReturnUrlOnce();
                this.opts.oidc.authorize();
            }
            catch (e) {
                this.logError(`authorize() failed. ctx=${context}`, e);
            }
            return;
        }
    }
    buildUrlFromAuthority(authority, path) {
        const base = (authority ?? '').replace(/\/+$/, '');
        const p = path.startsWith('/') ? path : `/${path}`;
        return `${base}${p}`;
    }
    async ensureAntiforgeryOnce(context) {
        const af = this.opts.antiforgery;
        if (!af?.enabled)
            return;
        if (this.antiforgeryDone)
            return;
        if (this.antiforgeryInFlight)
            return;
        const authority = await this.getAuthorityOnce();
        if (!authority)
            return;
        const url = this.buildUrlFromAuthority(authority, af.path ?? '/antiforgery/token');
        this.antiforgeryInFlight = true;
        try {
            this.logDebug(`antiforgery warm-up -> GET ${url} ctx=${context}`);
            await af.loader(url);
        }
        catch (e) {
            // best effort
            this.logWarn(`antiforgery warm-up failed (ignored). ctx=${context}`, e);
        }
        finally {
            // ✅ importante: aunque falle, no spamear
            this.antiforgeryDone = true;
            this.antiforgeryInFlight = false;
        }
    }
    // -----------------------------
    // Ping (IdP cookie)
    // -----------------------------
    async safePing(context) {
        try {
            const authority = await this.getAuthorityOnce();
            if (!authority) {
                this.logWarn(`safePing: missing authority. ctx=${context}`);
                return true; // no rompas UX
            }
            // ✅ Safari + cross-site: NO usar ping por fetch (ITP puede bloquear cookies)
            // Devolvemos null = "inconcluso/no confiable"
            if (this.isSafari() && this.isCrossSite(authority)) {
                this.logWarn(`safePing: skipped on Safari (cross-site). ctx=${context}`);
                return null;
            }
            const url = this.buildPingUrl(authority);
            const resp = await fetch(url, {
                method: 'GET',
                credentials: 'include',
                mode: 'cors',
                cache: 'no-store',
            });
            // Si el browser siguió un redirect, para nosotros es "no hay sesión"
            if (resp.redirected)
                return false;
            const finalUrl = (resp.url ?? '').toLowerCase();
            if (finalUrl.includes('/account/error/unauthorized'))
                return false;
            if (resp.status === 200)
                return true;
            if (resp.status === 401 || resp.status === 403)
                return false;
            if (resp.status === 404)
                return false;
            this.logWarn(`safePing: unexpected status=${resp.status}. ctx=${context}`);
            return true;
        }
        catch (e) {
            this.logWarn(`safePing: failed (ignored). ctx=${context}`, e);
            return true;
        }
    }
    async getAuthorityOnce() {
        try {
            const auth = await firstValueFrom(this.opts.authority$().pipe(take(1)));
            return (auth ?? '').trim();
        }
        catch {
            return '';
        }
    }
    buildPingUrl(authority) {
        const base = authority.replace(/\/+$/, '');
        const path = this.opts.pingPath.startsWith('/') ? this.opts.pingPath : `/${this.opts.pingPath}`;
        let url = `${base}${path}`;
        if (this.opts.cacheBuster) {
            const sep = url.includes('?') ? '&' : '?';
            url += `${sep}ts=${Date.now()}`;
        }
        return url;
    }
    isSafari() {
        // Evita confundir Chrome iOS (que también reporta Safari-ish).
        const ua = navigator.userAgent;
        const isApple = /Macintosh|iPhone|iPad|iPod/.test(ua);
        const isSafari = /Safari/.test(ua) && !/Chrome|CriOS|Edg|EdgiOS|OPR|FxiOS/.test(ua);
        return isApple && isSafari;
    }
    isCrossSite(authority) {
        try {
            const a = new URL(authority);
            const here = window.location;
            // Mínimo viable: host distinto => potencialmente cross-site.
            // (Para tu caso localhost vs sb-idp..., esto alcanza.)
            return a.host.toLowerCase() !== here.host.toLowerCase();
        }
        catch {
            return true;
        }
    }
    // -----------------------------
    // sessionStorage flags (anti-loop)
    // -----------------------------
    canTryPromptNoneOnce() {
        try {
            if (sessionStorage.getItem(this.promptNoneOnceKey) === '1')
                return false;
            sessionStorage.setItem(this.promptNoneOnceKey, '1');
            return true;
        }
        catch {
            return true;
        }
    }
    clearPromptNoneOnce() {
        try {
            sessionStorage.removeItem(this.promptNoneOnceKey);
        }
        catch {
            /* no-op */
        }
    }
    canTryInteractiveOnce() {
        try {
            if (sessionStorage.getItem(this.interactiveOnceKey) === '1')
                return false;
            sessionStorage.setItem(this.interactiveOnceKey, '1');
            return true;
        }
        catch {
            return true;
        }
    }
    clearInteractiveOnce() {
        try {
            sessionStorage.removeItem(this.interactiveOnceKey);
        }
        catch {
            /* no-op */
        }
    }
    isLogoutDisabled() {
        try {
            return sessionStorage.getItem(this.logoutDisabledKey) === '1';
        }
        catch {
            return false;
        }
    }
    setLogoutDisabled() {
        try {
            sessionStorage.setItem(this.logoutDisabledKey, '1');
        }
        catch {
            /* no-op */
        }
    }
    clearLogoutDisabled() {
        try {
            sessionStorage.removeItem(this.logoutDisabledKey);
        }
        catch {
            /* no-op */
        }
    }
    rememberReturnUrl() {
        this.saveReturnUrlOnce();
    }
    saveReturnUrlOnce() {
        try {
            if (sessionStorage.getItem(this.returnUrlPendingKey) === '1')
                return;
            const href = window.location.href;
            console.log('[SSO] saveReturnUrlOnce()', {
                href: window.location.href,
                path: window.location.pathname,
                pending: sessionStorage.getItem(this.returnUrlPendingKey),
                canSessionStorage: (() => { try {
                    sessionStorage.setItem('__t', '1');
                    sessionStorage.removeItem('__t');
                    return true;
                }
                catch {
                    return false;
                } })(),
            });
            if (this.isOidcCallbackUrl(href))
                return;
            if (window.location.pathname.startsWith('/logout'))
                return;
            const u = new URL(href, window.location.origin);
            const path = u.pathname;
            const target = u.pathname + u.search + u.hash; // 👈 no depende del origin
            if (path === '/')
                return;
            // ✅ VALIDACIÓN DE SEGURIDAD
            if (!this.isAllowedReturnPath(path)) {
                this.logWarn(`returnUrl rejected (not allowed): ${path}`);
                return;
            }
            sessionStorage.setItem(this.returnUrlKey, target);
            sessionStorage.setItem(this.returnUrlPendingKey, '1');
            this.logDebug(`returnUrl saved: ${target}`);
        }
        catch {
            /* no-op */
        }
    }
    clearReturnUrlPending() {
        try {
            sessionStorage.removeItem(this.returnUrlPendingKey);
            sessionStorage.removeItem(this.returnUrlKey);
        }
        catch {
            /* no-op */
        }
    }
    consumeReturnUrl() {
        try {
            const pending = sessionStorage.getItem(this.returnUrlPendingKey);
            const stored = sessionStorage.getItem(this.returnUrlKey);
            console.log('[SSO] consumeReturnUrl()', {
                pending,
                stored,
            });
            // ✅ Consumir si HAY returnUrlKey, aunque pending falte (más robusto en Safari/Mac)
            const target = stored || '';
            // ✅ limpieza one-shot SIEMPRE (anti-loop)
            sessionStorage.removeItem(this.returnUrlPendingKey);
            sessionStorage.removeItem(this.returnUrlKey);
            return target || null;
        }
        catch {
            return null;
        }
    }
    tryRestoreAfterLogin(router, opts) {
        try {
            const saved = this.consumeReturnUrl();
            console.log(`>>>> tryRestoreAfterLogin saved = ${saved}`);
            if (!saved)
                return;
            // ✅ Acepta:
            // - target relativo: "/clientes/123?x=1#sec"
            // - href absoluto:   "https://localhost:4205/clientes/123?x=1#sec"
            let target = '';
            try {
                // Si es absoluto, lo normalizamos a path+search+hash
                const u = new URL(saved);
                target = u.pathname + u.search + u.hash;
            }
            catch {
                // Si es relativo, lo usamos tal cual (pero normalizamos con origin)
                const u = new URL(saved, window.location.origin);
                target = u.pathname + u.search + u.hash;
            }
            const pathOnly = target.split('?')[0].split('#')[0];
            // ✅ guard mínimo: jamás restaurar a rutas internas de auth/logout
            if (pathOnly.startsWith('/auth/callback') ||
                pathOnly.startsWith('/auth/restore') ||
                pathOnly.startsWith('/auth/unauthorized') ||
                pathOnly.startsWith('/logout')) {
                this.logDebug(`restore ignored (auth route): ${pathOnly}`);
                return;
            }
            const current = window.location.pathname +
                window.location.search +
                window.location.hash;
            if (current === target)
                return;
            this.logDebug(`restore -> ${target}`);
            console.log(`>>> tryRestoreAfterLogin navigateByUrl -> ${target} replaceUrl=${opts?.replaceUrl ?? true}`);
            void router.navigateByUrl(target, { replaceUrl: opts?.replaceUrl ?? true });
        }
        catch (e) {
            this.logWarn(`restore failed (ignored).`, e);
        }
    }
    isAllowedReturnPath(pathname) {
        const list = this.opts.allowedReturnUrlPrefixes;
        // Si no hay whitelist → comportamiento actual (permitir todo)
        if (!list || list.length === 0)
            return true;
        return list.some(prefix => pathname === prefix || pathname.startsWith(prefix + '/'));
    }
    // -----------------------------
    // Logging
    // -----------------------------
    async getConfiguredLogLevel() {
        try {
            const cfg = await firstValueFrom(this.opts.oidc.getConfiguration().pipe(take(1)));
            const raw = cfg?.logLevel;
            if (typeof raw === 'number')
                return this.clampLogLevel(raw);
            if (typeof raw === 'string') {
                const s = raw.toLowerCase();
                if (s.includes('debug'))
                    return SimpleLogLevel.Debug;
                if (s.includes('info'))
                    return SimpleLogLevel.Info;
                if (s.includes('warn'))
                    return SimpleLogLevel.Warn;
                if (s.includes('error'))
                    return SimpleLogLevel.Error;
                if (s.includes('none') || s.includes('off'))
                    return SimpleLogLevel.None;
            }
            return this.opts.defaultLogLevel;
        }
        catch {
            return this.opts.defaultLogLevel;
        }
    }
    clampLogLevel(v) {
        if (v <= 0)
            return SimpleLogLevel.None;
        if (v === 1)
            return SimpleLogLevel.Error;
        if (v === 2)
            return SimpleLogLevel.Warn;
        if (v === 3)
            return SimpleLogLevel.Info;
        return SimpleLogLevel.Debug;
    }
    async logAt(level, msg, err) {
        const cfgLevel = await this.getConfiguredLogLevel();
        if (cfgLevel < level)
            return;
        const prefix = `[${this.opts.logPrefix}]`;
        if (level === SimpleLogLevel.Error)
            return void console.error(prefix, msg, err ?? '');
        if (level === SimpleLogLevel.Warn)
            return void console.warn(prefix, msg, err ?? '');
        if (level === SimpleLogLevel.Info)
            return void console.info(prefix, msg, err ?? '');
        if (level === SimpleLogLevel.Debug)
            return void console.log(prefix, msg, err ?? '');
    }
    logDebug(msg, err) {
        void this.logAt(SimpleLogLevel.Debug, msg, err);
    }
    logWarn(msg, err) {
        void this.logAt(SimpleLogLevel.Warn, msg, err);
    }
    logError(msg, err) {
        void this.logAt(SimpleLogLevel.Error, msg, err);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: SsoSessionGuardService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: SsoSessionGuardService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: SsoSessionGuardService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

// sso-session-guard.providers.ts
//
// Plug-and-play providers para arrancar el SsoSessionGuardService automáticamente.
// Angular 19+ => APP_INITIALIZER está deprecated: usamos provideAppInitializer().
//
// Uso: en app.config.ts => providers: [ provideSsoSessionGuard({ ... }) ]
//** 1) Cómo lo usás en tu App (BOD) sin “interferir”
//** En tu logout() llamá una línea extra para que el guard no intente recuperar:
/* TS
logout() {
  this.ssoGuard.markLogoutFromThisApp(); // <- agrega esto
  this.oidcSecurityService.logoff().subscribe();
}
*/
//** Cuando autenticás OK (o en tu subscribe de isAuthenticated$ cuando true), limpiá el flag “logoutDisabled”:
/* TS
if (isAuthenticated) {
  this.ssoGuard.clearLogoutDisabledFlag();
}
*/
/** Token para inyectar la config */
const SSO_SESSION_GUARD_CONFIG = new InjectionToken('SSO_SESSION_GUARD_CONFIG');
/**
 * Provider “único” para apps: instala el guard apenas levanta la app.
 * Importante: por defecto NO bloquea el bootstrap (no devuelve Promise/Observable).
 */
function provideSsoSessionGuard(config) {
    return makeEnvironmentProviders([
        { provide: SSO_SESSION_GUARD_CONFIG, useValue: config },
        provideAppInitializer(() => {
            const guard = inject(SsoSessionGuardService);
            const oidc = inject(OidcSecurityService);
            const cfg = inject(SSO_SESSION_GUARD_CONFIG);
            const http = inject(HttpClient);
            const opts = {
                appNs: cfg.appNs,
                oidc,
                // authority SIEMPRE desde la config activa del oidc-client
                authority$: () => oidc.getConfiguration().pipe(take$1(1), map(c => c?.authority)),
                pingPath: cfg.pingPath,
                cacheBuster: cfg.cacheBuster,
                minIntervalMs: cfg.minIntervalMs,
                onlyWhenAuthenticated: cfg.onlyWhenAuthenticated,
                forceLoginIfNoIdpSession: cfg.forceLoginIfNoIdpSession,
                recoverMode: cfg.recoverMode,
                events: cfg.events,
                logPrefix: cfg.logPrefix,
                defaultLogLevel: cfg.defaultLogLevel,
                antiforgery: cfg.antiforgery?.enabled
                    ? {
                        enabled: true,
                        path: cfg.antiforgery.path ?? '/antiforgery/token',
                        run: cfg.antiforgery.run ?? 'beforePing',
                        loader: (url) => firstValueFrom(http.get(url, {
                            withCredentials: true,
                            responseType: 'text',
                        }).pipe(map(() => void 0), catchError(() => of(void 0)))),
                    }
                    : undefined,
                allowedReturnUrlPrefixes: cfg.allowedReturnUrlPrefixes,
            };
            // ✅ instala hooks (pageshow/focus/visibilitychange), throttle, inFlight, etc.
            guard.start(opts);
            // OJO: si querés que también haga “bootstrap” (ping + checkAuth) automáticamente,
            // lo ideal es que sea opt-in. Si tu app YA hace checkAuth en otro lado,
            // NO lo llames para no duplicar.
            //
            // return guard.bootstrapAuthOnce(); // <- esto sí bloquearía si devuelve Promise/Observable
            //
            return;
        }),
    ]);
}

const INITIAL_STATE = {
    isAuthenticated: false,
    config: null,
    accessToken: '',
    accessPayload: null,
    idToken: '',
    idPayload: null,
    userInfo: null,
    userInfoLoadedAt: null,
};
class AuthSessionFacade {
    oidc = inject(OidcSecurityService);
    guard = inject(SsoSessionGuardService);
    router = inject(Router);
    http = inject(HttpClient);
    subs = [];
    started = false;
    _state$ = new BehaviorSubject(INITIAL_STATE);
    state$ = this._state$.asObservable();
    onLogin$ = this.state$.pipe(map$1(s => s.isAuthenticated), distinctUntilChanged(), pairwise(), filter(([prev, curr]) => !prev && curr), map$1(() => void 0), shareReplay({ bufferSize: 1, refCount: true }));
    onLogout$ = this.state$.pipe(map$1(s => s.isAuthenticated), distinctUntilChanged(), pairwise(), filter(([prev, curr]) => prev && !curr), map$1(() => void 0), shareReplay({ bufferSize: 1, refCount: true }));
    _logoutRequested$ = new Subject();
    onLogoutRequested$ = this._logoutRequested$.asObservable();
    // -------------------------
    // BOOTSTRAP
    // -------------------------
    bootstrap() {
        if (this.started)
            return;
        this.started = true;
        const path = window.location.pathname || '';
        // ✅ cargar config 1 vez al iniciar (aunque no haya sesión)
        this.oidc.getConfiguration().pipe(take$1(1)).subscribe(cfg => {
            const cur = this._state$.value;
            this._state$.next({
                ...cur,
                config: cfg,
            });
        });
        // ruta /logout
        if (path.startsWith('/logout')) {
            this.guard.markLogoutFromThisApp();
            this.oidc.logoffLocal();
            // dejar state consistente
            this._state$.next({ ...this._state$.value, isAuthenticated: false });
            return;
        }
        // escuchar cambios de auth del oidc
        this.subs.push(this.oidc.isAuthenticated$.subscribe(({ isAuthenticated }) => {
            if (isAuthenticated) {
                this.guard.clearLogoutDisabledFlag();
            }
            // refrescar state base (auth + config)
            this.oidc.getConfiguration().pipe(take$1(1)).subscribe(cfg => {
                const cur = this._state$.value;
                this._state$.next({
                    ...cur,
                    isAuthenticated,
                    config: cfg,
                });
                // ✅ si autenticó, refrescar tokens/payloads en el state
                if (isAuthenticated) {
                    this.refreshTokens();
                }
                else {
                    // limpiar tokens/payloads/userinfo
                    this._state$.next({
                        ...this._state$.value,
                        accessToken: '',
                        accessPayload: null,
                        idToken: '',
                        idPayload: null,
                        userInfo: null,
                        userInfoLoadedAt: null,
                    });
                }
            });
        }));
        // bootstrap SSO
        void this.guard
            .bootstrapAuthOnce({ doCheckAuth: true, router: this.router })
            .catch(() => { });
    }
    // -------------------------
    // ACTIONS
    // -------------------------
    login() {
        this.guard.rememberReturnUrl();
        this.oidc.authorize();
    }
    logout() {
        this._logoutRequested$.next();
        // ✅ forzar transición local inmediata para que onLogout$ dispare siempre
        const cur = this._state$.value;
        if (cur.isAuthenticated) {
            this._state$.next({
                ...cur,
                isAuthenticated: false,
                accessToken: '',
                accessPayload: null,
                idToken: '',
                idPayload: null,
                userInfo: null,
                userInfoLoadedAt: null,
            });
        }
        this.guard.markLogoutFromThisApp();
        this.oidc.logoff().subscribe();
    }
    refresh() {
        return this.oidc.forceRefreshSession().pipe(switchMap(r => {
            // cuando refresca, actualizamos tokens/payloads en state
            this.refreshTokens();
            return of(r);
        }));
    }
    goUserProfile() {
        this.oidc.getConfiguration().pipe(take$1(1)).subscribe(cfg => {
            const authority = cfg.authority;
            const clientId = cfg.clientId;
            const currentUrl = window.location.origin + window.location.pathname;
            const returnUrl = encodeURIComponent(currentUrl);
            window.location.href =
                `${authority}/account/profile?client_id=${clientId}&returnUrl=${returnUrl}`;
        });
    }
    getAccessToken() {
        return this.oidc.getAccessToken();
    }
    // -------------------------
    // LOADERS (STATE “RICO”)
    // -------------------------
    refreshTokens() {
        forkJoin({
            at: this.oidc.getAccessToken().pipe(take$1(1)),
            atp: this.oidc.getPayloadFromAccessToken().pipe(take$1(1)),
            it: this.oidc.getIdToken().pipe(take$1(1)),
            itp: this.oidc.getPayloadFromIdToken().pipe(take$1(1)),
        }).subscribe({
            next: ({ at, atp, it, itp }) => {
                const cur = this._state$.value;
                this._state$.next({
                    ...cur,
                    accessToken: at ?? '',
                    accessPayload: atp ?? null,
                    idToken: it ?? '',
                    idPayload: itp ?? null,
                });
            },
            error: _ => {
                // no matamos el flujo si falla algo de payload
            }
        });
    }
    refreshUserInfo() {
        const cur = this._state$.value;
        if (!cur.isAuthenticated || !cur.config?.authority) {
            this._state$.next({ ...cur, userInfo: null, userInfoLoadedAt: null });
            return;
        }
        forkJoin([
            this.oidc.getAccessToken().pipe(take$1(1)),
            this.oidc.getConfiguration().pipe(take$1(1)),
        ])
            .pipe(switchMap(([token, cfg]) => {
            const authority = cfg?.authority ?? '';
            if (!token || !authority)
                return of({ error: 'missing token/authority' });
            const headers = new HttpHeaders({ Authorization: `Bearer ${token}` });
            return this.http.get(`${authority}/connect/userinfo`, { headers }).pipe(catchError(err => of({
                error: err?.message ?? 'UserInfo error',
                status: err?.status,
            })));
        }))
            .subscribe(data => {
            const now = new Date();
            const cur2 = this._state$.value;
            this._state$.next({
                ...cur2,
                userInfo: data ?? null,
                userInfoLoadedAt: now,
            });
        });
    }
    clearUserInfo() {
        const cur = this._state$.value;
        this._state$.next({ ...cur, userInfo: null, userInfoLoadedAt: null });
    }
    // -------------------------
    // CLEANUP
    // -------------------------
    ngOnDestroy() {
        this.subs.forEach(s => s.unsubscribe());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: AuthSessionFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: AuthSessionFacade, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: AuthSessionFacade, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * Public API Surface of mma-sso-session-guard
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AuthSessionFacade, SSO_SESSION_GUARD_CONFIG, SimpleLogLevel, SsoSessionGuardService, provideSsoSessionGuard };
//# sourceMappingURL=mma-sso-session-guard.mjs.map
