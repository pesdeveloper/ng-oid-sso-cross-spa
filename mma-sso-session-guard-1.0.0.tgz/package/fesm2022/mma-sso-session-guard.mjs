import * as i0 from '@angular/core';
import { Injectable, InjectionToken, makeEnvironmentProviders, provideAppInitializer, inject, computed, signal } from '@angular/core';
import { firstValueFrom, map, of, take as take$1, BehaviorSubject, Subject, forkJoin } from 'rxjs';
import { take, catchError, map as map$1, distinctUntilChanged, pairwise, filter, shareReplay, switchMap, finalize } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { OidcSecurityService, PublicEventsService, EventTypes } from 'angular-auth-oidc-client';
import { Router } from '@angular/router';
import { toSignal } from '@angular/core/rxjs-interop';

// sso-session-guard.service.ts
// -----------------------------
// Tipos y enums públicos
// -----------------------------
/** Nivel de log simple */
var SimpleLogLevel;
(function (SimpleLogLevel) {
    SimpleLogLevel[SimpleLogLevel["None"] = 0] = "None";
    SimpleLogLevel[SimpleLogLevel["Error"] = 1] = "Error";
    SimpleLogLevel[SimpleLogLevel["Warn"] = 2] = "Warn";
    SimpleLogLevel[SimpleLogLevel["Info"] = 3] = "Info";
    SimpleLogLevel[SimpleLogLevel["Debug"] = 4] = "Debug";
})(SimpleLogLevel || (SimpleLogLevel = {}));
class SsoSessionGuardService {
    started = false;
    opts;
    lastPingAt = 0;
    pingInFlight = false;
    attached = false;
    detachFns = [];
    // Keys (sessionStorage)
    promptNoneOnceKey = '';
    interactiveOnceKey = '';
    logoutDisabledKey = '';
    antiforgeryDone = false;
    antiforgeryInFlight = false;
    isResuming = false;
    start(options) {
        if (this.started)
            return;
        this.started = true;
        const pingPath = options.pingPath ?? '/api/session/ping';
        const cacheBuster = options.cacheBuster ?? true;
        const minIntervalMs = options.minIntervalMs ?? 5000;
        const onlyWhenAuthenticated = options.onlyWhenAuthenticated ?? false;
        const forceLoginIfNoIdpSession = options.forceLoginIfNoIdpSession ?? false;
        const recoverMode = options.recoverMode ?? 'promptNone';
        const events = options.events ?? ['pageshow', 'visibilitychange', 'focus'];
        const logPrefix = options.logPrefix ?? 'SSO';
        const defaultLogLevel = options.defaultLogLevel ?? SimpleLogLevel.Debug;
        const allowedReturnUrlPrefixes = options.allowedReturnUrlPrefixes ?? [];
        const ignoredReturnUrlPrefixes = options.ignoredReturnUrlPrefixes ?? [
            '/logout',
            '/silent-renew',
            '/assets',
        ];
        this.opts = {
            ...options,
            pingPath,
            cacheBuster,
            minIntervalMs,
            onlyWhenAuthenticated,
            forceLoginIfNoIdpSession,
            recoverMode,
            events,
            logPrefix,
            defaultLogLevel,
            allowedReturnUrlPrefixes,
            ignoredReturnUrlPrefixes,
        };
        // SessionStorage keys namespaced
        this.promptNoneOnceKey = `${this.opts.appNs}:oidc:promptnone:once`;
        this.interactiveOnceKey = `${this.opts.appNs}:oidc:interactive:once`;
        this.logoutDisabledKey = `${this.opts.appNs}:oidc:recover:disabled`;
        this.logDebug(`antiforgery enabled=${!!this.opts.antiforgery?.enabled} run=${this.opts.antiforgery?.run ?? 'beforePing'} path=${this.opts.antiforgery?.path ?? ''}`);
        this.attachHooks();
    }
    /**
     * ✅ Verificación inicial "de verdad" al entrar a la app.
     * - antiforgery (si enabled) -> ping -> si no IdP => logoffLocal
     * - si doCheckAuth: checkAuth y, si hay cookie IdP pero no auth local => recover según recoverMode
     */
    async bootstrapAuthOnce(params) {
        const doCheckAuth = params?.doCheckAuth ?? false;
        // ✅ 0) Capturar deep-link ANTES de cualquier cosa (si aplica)
        this.captureReturnUrlIfNeeded('bootstrap');
        if (this.opts.antiforgery?.enabled) {
            await this.ensureAntiforgeryOnce('bootstrap');
        }
        const ping = await this.safePing('bootstrap');
        this.logDebug(`bootstrap: ping=${ping} (true=hasIdp, false=noIdp, null=unknown)`);
        if (ping === false) {
            await this.handleNoIdpSession('bootstrap');
            return;
        }
        if (!doCheckAuth)
            return;
        const resp = await firstValueFrom(this.opts.oidc.checkAuth().pipe(take(1)));
        this.logDebug(`bootstrap: checkAuth isAuthenticated=${resp?.isAuthenticated}`);
        if (!resp?.isAuthenticated) {
            await this.handleHasIdpButNoLocalAuth('bootstrap');
        }
        else {
            this.clearPromptNoneOnce();
            this.clearInteractiveOnce();
            this.clearLogoutDisabled();
        }
    }
    /** Llamalo cuando el usuario hace logout desde ESTA app */
    markLogoutFromThisApp() {
        this.setLogoutDisabled();
        this.clearPromptNoneOnce();
        this.clearInteractiveOnce();
    }
    clearLogoutDisabledFlag() {
        this.clearLogoutDisabled();
    }
    getReturnUrlKey() {
        const url = `${this.opts.appNs}:returnUrl`;
        this.logDebug(`>>>> getReturnUrlKey : GET url = '${url}'`);
        return url;
    }
    setReturnUrl(url, opts) {
        const key = this.getReturnUrlKey();
        const overwrite = opts?.overwrite ?? false;
        try {
            if (!overwrite) {
                const existing = sessionStorage.getItem(key);
                if (existing) {
                    this.logDebug(`setReturnUrl ignored (already set). existing='${existing}' new='${url}'`);
                    return;
                }
            }
            sessionStorage.setItem(key, url);
            this.logDebug(`setReturnUrl stored '${url}' overwrite=${overwrite}`);
        }
        catch { }
    }
    popReturnUrl() {
        try {
            const k = this.getReturnUrlKey();
            const v = sessionStorage.getItem(k);
            if (v)
                sessionStorage.removeItem(k);
            this.logDebug(`>>>> popReturnUrl : k = '${k}' , v = '${v}'`);
            return v;
        }
        catch {
            this.logDebug(`>>>> popReturnUrl CATCH-ERROR`);
            return null;
        }
    }
    // -----------------------------
    // Hooks
    // -----------------------------
    attachHooks() {
        if (this.attached)
            return;
        this.attached = true;
        const { events } = this.opts;
        if (events.includes('pageshow')) {
            const fn = (ev) => {
                const persisted = ev?.persisted === true;
                // BFCache/back-forward
                if (!persisted) {
                    this.logDebug(`pageshow ignored (persisted=false)`);
                    return;
                }
                this.onResume(`pageshow persisted=true`);
            };
            window.addEventListener('pageshow', fn);
            this.detachFns.push(() => window.removeEventListener('pageshow', fn));
        }
        if (events.includes('visibilitychange')) {
            const fn = () => {
                if (document.visibilityState === 'visible') {
                    this.onResume('visibilitychange visible');
                }
            };
            document.addEventListener('visibilitychange', fn);
            this.detachFns.push(() => document.removeEventListener('visibilitychange', fn));
        }
        if (events.includes('focus')) {
            const fn = () => this.onResume('focus');
            window.addEventListener('focus', fn);
            this.detachFns.push(() => window.removeEventListener('focus', fn));
        }
        this.logDebug(`hooks attached: ${events.join(', ')}`);
    }
    isOidcCallbackUrl(url) {
        try {
            const u = new URL(url, window.location.origin);
            const p = u.searchParams;
            return p.has('code') || p.has('state') || p.has('error') || p.has('iss') || p.has('session_state');
        }
        catch {
            return /[?&](code|state|error|iss|session_state)=/i.test(url);
        }
    }
    async onResume(reason) {
        if (!this.started)
            return;
        const url = window.location.href;
        // callback => no tocar nada
        if (this.isOidcCallbackUrl(url)) {
            this.logDebug(`onResume(${reason}) ignored: OIDC callback URL`);
            return;
        }
        // logout desde esta app => no recuperar
        if (this.isLogoutDisabled()) {
            this.logDebug(`resume ignored (logoutDisabled=true). reason=${reason}`);
            return;
        }
        if (this.isResuming) {
            this.logDebug(`onResume(${reason}) ignored: already running`);
            return;
        }
        this.isResuming = true;
        try {
            // onlyWhenAuthenticated: si no hay accessToken local, no ping
            if (this.opts.onlyWhenAuthenticated) {
                let token = '';
                try {
                    token = await firstValueFrom(this.opts.oidc.getAccessToken().pipe(take(1)));
                }
                catch {
                    token = '';
                }
                if (!token) {
                    this.logDebug(`resume ignored (no accessToken). reason=${reason}`);
                    return;
                }
            }
            // throttle
            const now = Date.now();
            if (now - this.lastPingAt < this.opts.minIntervalMs) {
                this.logDebug(`resume throttled (${now - this.lastPingAt}ms < ${this.opts.minIntervalMs}ms). reason=${reason}`);
                return;
            }
            // in-flight
            if (this.pingInFlight) {
                this.logDebug(`resume ignored (pingInFlight=true). reason=${reason}`);
                return;
            }
            this.lastPingAt = now;
            this.pingInFlight = true;
            try {
                if (this.opts.antiforgery?.enabled) {
                    await this.ensureAntiforgeryOnce(`resume:${reason}`);
                }
                this.logDebug(`resume -> ping IdP session... reason=${reason}`);
                const ping = await this.safePing(`resume:${reason}`);
                this.logDebug(`resume ping result=${ping} (true=hasIdp, false=noIdp, null=unknown)`);
                if (ping === false) {
                    await this.handleNoIdpSession(`resume:${reason}`);
                    return;
                }
                const isLocalAuth = await this.isLocallyAuthenticated();
                this.logDebug(`resume local isAuthenticated=${isLocalAuth}`);
                if (!isLocalAuth) {
                    await this.handleHasIdpButNoLocalAuth(`resume:${reason}`);
                }
                else {
                    this.clearPromptNoneOnce();
                    this.clearInteractiveOnce();
                    this.clearLogoutDisabled();
                }
            }
            finally {
                this.pingInFlight = false;
            }
        }
        catch (e) {
            this.logWarn(`resume failed (ignored). reason=${reason}`, e);
        }
        finally {
            this.isResuming = false;
        }
    }
    async isLocallyAuthenticated() {
        try {
            const resp = await firstValueFrom(this.opts.oidc.checkAuth().pipe(take(1)));
            return !!resp?.isAuthenticated;
        }
        catch {
            return false;
        }
    }
    async handleNoIdpSession(context) {
        this.logWarn(`IdP session missing -> logoffLocal(). ctx=${context}`);
        try {
            this.opts.oidc.logoffLocal();
        }
        catch (e) {
            this.logWarn(`logoffLocal failed (ignored). ctx=${context}`, e);
        }
        // refresh state (best effort)
        try {
            const resp = await firstValueFrom(this.opts.oidc.checkAuth().pipe(take(1)));
            this.logDebug(`after logoffLocal: checkAuth isAuthenticated=${resp?.isAuthenticated} ctx=${context}`);
        }
        catch (e) {
            this.logWarn(`after logoffLocal: checkAuth failed (ignored). ctx=${context}`, e);
        }
        if (this.opts.forceLoginIfNoIdpSession) {
            const can = this.canTryInteractiveOnce();
            this.logDebug(`office365-like: forceLoginIfNoIdpSession=true canInteractive=${can} ctx=${context}`);
            if (can) {
                try {
                    this.captureReturnUrlIfNeeded(`forceLogin:${context}`);
                    this.opts.oidc.authorize();
                }
                catch (e) {
                    this.logError(`authorize() failed. ctx=${context}`, e);
                }
            }
        }
    }
    async handleHasIdpButNoLocalAuth(context) {
        const mode = this.opts.recoverMode;
        if (mode === 'none') {
            this.logDebug(`recoverMode=none (no action). ctx=${context}`);
            return;
        }
        if (mode === 'promptNone') {
            const can = this.canTryPromptNoneOnce();
            this.logDebug(`recoverMode=promptNone canTry=${can} ctx=${context}`);
            if (!can)
                return;
            if (this.opts.antiforgery?.enabled && (this.opts.antiforgery.run ?? 'beforePing') === 'beforeRecover') {
                await this.ensureAntiforgeryOnce(`recover:${context}`);
            }
            try {
                this.captureReturnUrlIfNeeded(`recover:promptNone:${context}`);
                this.opts.oidc.authorize(undefined, { customParams: { prompt: 'none' } });
            }
            catch (e) {
                this.logError(`authorize(prompt=none) failed. ctx=${context}`, e);
            }
            return;
        }
        if (mode === 'interactive') {
            const can = this.canTryInteractiveOnce();
            this.logDebug(`recoverMode=interactive canTry=${can} ctx=${context}`);
            if (!can)
                return;
            try {
                this.captureReturnUrlIfNeeded(`recover:interactive:${context}`);
                this.opts.oidc.authorize();
            }
            catch (e) {
                this.logError(`authorize() failed. ctx=${context}`, e);
            }
            return;
        }
    }
    // -----------------------------
    // Antiforgery
    // -----------------------------
    buildUrlFromAuthority(authority, path) {
        const base = (authority ?? '').replace(/\/+$/, '');
        const p = path.startsWith('/') ? path : `/${path}`;
        return `${base}${p}`;
    }
    async ensureAntiforgeryOnce(context) {
        const af = this.opts.antiforgery;
        if (!af?.enabled)
            return;
        if (this.antiforgeryDone)
            return;
        if (this.antiforgeryInFlight)
            return;
        const authority = await this.getAuthorityOnce();
        if (!authority)
            return;
        const url = this.buildUrlFromAuthority(authority, af.path ?? '/antiforgery/token');
        this.antiforgeryInFlight = true;
        try {
            this.logDebug(`antiforgery warm-up -> GET ${url} ctx=${context}`);
            await af.loader(url);
        }
        catch (e) {
            this.logWarn(`antiforgery warm-up failed (ignored). ctx=${context}`, e);
        }
        finally {
            this.antiforgeryDone = true;
            this.antiforgeryInFlight = false;
        }
    }
    // -----------------------------
    // Ping
    // -----------------------------
    async safePing(context) {
        try {
            const authority = await this.getAuthorityOnce();
            if (!authority) {
                this.logWarn(`safePing: missing authority. ctx=${context}`);
                return true; // best-effort
            }
            // Safari cross-site: ping inconcluso (no romper UX)
            if (this.isSafari() && this.isCrossSite(authority)) {
                this.logWarn(`safePing: skipped on Safari (cross-site). ctx=${context}`);
                return null;
            }
            const url = this.buildPingUrl(authority);
            const resp = await fetch(url, {
                method: 'GET',
                credentials: 'include',
                mode: 'cors',
                cache: 'no-store',
            });
            if (resp.redirected)
                return false;
            const finalUrl = (resp.url ?? '').toLowerCase();
            if (finalUrl.includes('/account/error/unauthorized'))
                return false;
            if (resp.status === 200)
                return true;
            if (resp.status === 401 || resp.status === 403)
                return false;
            if (resp.status === 404)
                return false;
            this.logWarn(`safePing: unexpected status=${resp.status}. ctx=${context}`);
            return true;
        }
        catch (e) {
            this.logWarn(`safePing: failed (ignored). ctx=${context}`, e);
            return true;
        }
    }
    async getAuthorityOnce() {
        try {
            const auth = await firstValueFrom(this.opts.authority$().pipe(take(1)));
            return (auth ?? '').trim();
        }
        catch {
            return '';
        }
    }
    buildPingUrl(authority) {
        const base = authority.replace(/\/+$/, '');
        const path = this.opts.pingPath.startsWith('/') ? this.opts.pingPath : `/${this.opts.pingPath}`;
        let url = `${base}${path}`;
        if (this.opts.cacheBuster) {
            const sep = url.includes('?') ? '&' : '?';
            url += `${sep}ts=${Date.now()}`;
        }
        return url;
    }
    isSafari() {
        const ua = navigator.userAgent;
        const isApple = /Macintosh|iPhone|iPad|iPod/.test(ua);
        const isSafari = /Safari/.test(ua) && !/Chrome|CriOS|Edg|EdgiOS|OPR|FxiOS/.test(ua);
        return isApple && isSafari;
    }
    isCrossSite(authority) {
        try {
            const a = new URL(authority);
            const here = window.location;
            return a.host.toLowerCase() !== here.host.toLowerCase();
        }
        catch {
            return true;
        }
    }
    captureReturnUrlIfNeeded(context) {
        try {
            const href = window.location.href;
            this.logDebug(`>>> captureReturnUrl START: href=${href}`);
            // 1️⃣ nunca capturar callback OIDC
            if (this.isOidcCallbackUrl(href)) {
                this.logDebug(`captureReturnUrl ignored: OIDC callback. ctx=${context}`);
                return;
            }
            // 2️⃣ path + query
            const pathname = window.location.pathname || '';
            const rel = pathname + (window.location.search || '');
            // 3️⃣ aplicar filtro whitelist/ignore/assets sobre el PATH
            if (!this.isReturnUrlAllowed(pathname)) {
                this.logDebug(`captureReturnUrl ignored: not allowed pathname='${pathname}'. ctx=${context}`);
                return;
            }
            // 4️⃣ first-wins (no pisar)
            const key = this.getReturnUrlKey();
            if (sessionStorage.getItem(key)) {
                this.logDebug(`captureReturnUrl ignored: already stored. ctx=${context}`);
                return;
            }
            sessionStorage.setItem(key, rel);
            this.logDebug(`>>>> captureReturnUrl stored '${rel}'. ctx=${context}`);
        }
        catch (e) {
            this.logWarn(`>>>> captureReturnUrl failed (ignored). ctx=${context}`, e);
        }
    }
    // -----------------------------
    // Flags anti-loop
    // -----------------------------
    canTryPromptNoneOnce() {
        try {
            if (sessionStorage.getItem(this.promptNoneOnceKey) === '1')
                return false;
            sessionStorage.setItem(this.promptNoneOnceKey, '1');
            return true;
        }
        catch {
            return true;
        }
    }
    clearPromptNoneOnce() {
        try {
            sessionStorage.removeItem(this.promptNoneOnceKey);
        }
        catch { }
    }
    canTryInteractiveOnce() {
        try {
            if (sessionStorage.getItem(this.interactiveOnceKey) === '1')
                return false;
            sessionStorage.setItem(this.interactiveOnceKey, '1');
            return true;
        }
        catch {
            return true;
        }
    }
    clearInteractiveOnce() {
        try {
            sessionStorage.removeItem(this.interactiveOnceKey);
        }
        catch { }
    }
    isLogoutDisabled() {
        try {
            return sessionStorage.getItem(this.logoutDisabledKey) === '1';
        }
        catch {
            return false;
        }
    }
    setLogoutDisabled() {
        try {
            sessionStorage.setItem(this.logoutDisabledKey, '1');
        }
        catch { }
    }
    clearLogoutDisabled() {
        try {
            sessionStorage.removeItem(this.logoutDisabledKey);
        }
        catch { }
    }
    // --------------------------
    // Helpers  Normlizacion urls
    // --------------------------
    normalizePath(p) {
        if (!p)
            return '';
        // asegura leading slash y saca trailing slashes (excepto '/')
        let x = p.startsWith('/') ? p : '/' + p;
        x = x.length > 1 ? x.replace(/\/+$/, '') : x;
        return x;
    }
    isPrefixMatch(pathname, prefix) {
        const p = this.normalizePath(pathname);
        const pref = this.normalizePath(prefix);
        return p === pref || p.startsWith(pref + '/');
    }
    isAssetPath(pathname) {
        const p = (pathname ?? '').toLowerCase();
        // /assets/... o /favicon.ico
        if (p.startsWith('/assets/'))
            return true;
        if (p === '/favicon.ico')
            return true;
        // archivos estáticos típicos
        return (p.endsWith('.js') ||
            p.endsWith('.css') ||
            p.endsWith('.map') ||
            p.endsWith('.ico') ||
            p.endsWith('.png') ||
            p.endsWith('.jpg') ||
            p.endsWith('.jpeg') ||
            p.endsWith('.webp') ||
            p.endsWith('.svg') ||
            p.endsWith('.woff') ||
            p.endsWith('.woff2') ||
            p.endsWith('.ttf'));
    }
    isReturnUrlAllowed(pathname) {
        const p = this.normalizePath(pathname);
        // 0) root nunca
        if (!p || p === '/')
            return false;
        // 1) assets nunca
        if (this.isAssetPath(p))
            return false;
        // 2) ignore list (técnicos)
        const ignored = this.opts.ignoredReturnUrlPrefixes ?? [];
        if (ignored.some(x => this.isPrefixMatch(p, x)))
            return false;
        // 3) whitelist: si está vacía => NO capturar nada (seguro)
        const allowed = this.opts.allowedReturnUrlPrefixes ?? [];
        if (!allowed.length)
            return false;
        // 4) debe matchear algún prefijo permitido
        return allowed.some(x => this.isPrefixMatch(p, x));
    }
    // -----------------------------
    // Logging
    // -----------------------------
    async getConfiguredLogLevel() {
        try {
            const cfg = await firstValueFrom(this.opts.oidc.getConfiguration().pipe(take(1)));
            const raw = cfg?.logLevel;
            if (typeof raw === 'number')
                return this.clampLogLevel(raw);
            if (typeof raw === 'string') {
                const s = raw.toLowerCase();
                if (s.includes('debug'))
                    return SimpleLogLevel.Debug;
                if (s.includes('info'))
                    return SimpleLogLevel.Info;
                if (s.includes('warn'))
                    return SimpleLogLevel.Warn;
                if (s.includes('error'))
                    return SimpleLogLevel.Error;
                if (s.includes('none') || s.includes('off'))
                    return SimpleLogLevel.None;
            }
            return this.opts.defaultLogLevel;
        }
        catch {
            return this.opts.defaultLogLevel;
        }
    }
    clampLogLevel(v) {
        if (v <= 0)
            return SimpleLogLevel.None;
        if (v === 1)
            return SimpleLogLevel.Error;
        if (v === 2)
            return SimpleLogLevel.Warn;
        if (v === 3)
            return SimpleLogLevel.Info;
        return SimpleLogLevel.Debug;
    }
    async logAt(level, msg, err) {
        const cfgLevel = await this.getConfiguredLogLevel();
        if (cfgLevel < level)
            return;
        const prefix = `[${this.opts.logPrefix}]`;
        if (level === SimpleLogLevel.Error)
            return void console.error(prefix, msg, err ?? '');
        if (level === SimpleLogLevel.Warn)
            return void console.warn(prefix, msg, err ?? '');
        if (level === SimpleLogLevel.Info)
            return void console.info(prefix, msg, err ?? '');
        if (level === SimpleLogLevel.Debug)
            return void console.log(prefix, msg, err ?? '');
    }
    logDebug(msg, err) {
        void this.logAt(SimpleLogLevel.Debug, msg, err);
    }
    logWarn(msg, err) {
        void this.logAt(SimpleLogLevel.Warn, msg, err);
    }
    logError(msg, err) {
        void this.logAt(SimpleLogLevel.Error, msg, err);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: SsoSessionGuardService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: SsoSessionGuardService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: SsoSessionGuardService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

// sso-session-guard.providers.ts
//
// Plug-and-play providers para arrancar el SsoSessionGuardService automáticamente.
// Angular 19+ => APP_INITIALIZER está deprecated: usamos provideAppInitializer().
//
// Uso: en app.config.ts => providers: [ provideSsoSessionGuard({ ... }) ]
/** Token para inyectar la config */
const SSO_SESSION_GUARD_CONFIG = new InjectionToken('SSO_SESSION_GUARD_CONFIG');
/**
 * Provider “único” para apps: instala el guard apenas levanta la app.
 * Importante: por defecto NO bloquea el bootstrap.
 */
function provideSsoSessionGuard(config) {
    return makeEnvironmentProviders([
        { provide: SSO_SESSION_GUARD_CONFIG, useValue: config },
        provideAppInitializer(() => {
            const guard = inject(SsoSessionGuardService);
            const oidc = inject(OidcSecurityService);
            const cfg = inject(SSO_SESSION_GUARD_CONFIG);
            const http = inject(HttpClient);
            const opts = {
                appNs: cfg.appNs,
                oidc,
                // authority SIEMPRE desde la config activa del oidc-client
                authority$: () => oidc.getConfiguration().pipe(take$1(1), map(c => c?.authority)),
                pingPath: cfg.pingPath,
                cacheBuster: cfg.cacheBuster,
                minIntervalMs: cfg.minIntervalMs,
                onlyWhenAuthenticated: cfg.onlyWhenAuthenticated,
                forceLoginIfNoIdpSession: cfg.forceLoginIfNoIdpSession,
                recoverMode: cfg.recoverMode,
                events: cfg.events,
                logPrefix: cfg.logPrefix,
                defaultLogLevel: cfg.defaultLogLevel,
                antiforgery: cfg.antiforgery?.enabled
                    ? {
                        enabled: true,
                        path: cfg.antiforgery.path ?? '/antiforgery/token',
                        run: cfg.antiforgery.run ?? 'beforePing',
                        loader: (url) => firstValueFrom(http
                            .get(url, {
                            withCredentials: true,
                            responseType: 'text',
                        })
                            .pipe(map(() => void 0), catchError(() => of(void 0)))),
                    }
                    : undefined,
                allowedReturnUrlPrefixes: cfg.allowedReturnUrlPrefixes,
                ignoredReturnUrlPrefixes: cfg.ignoredReturnUrlPrefixes,
            };
            // ✅ instala hooks (pageshow/focus/visibilitychange), throttle, inFlight, etc.
            guard.start(opts);
            // ✅ opcional: bootstrap automático (sin bloquear el arranque)
            if (cfg.autoBootstrap) {
                const doCheckAuth = cfg.autoBootstrapDoCheckAuth ?? true;
                void guard.bootstrapAuthOnce({ doCheckAuth }).catch(() => { });
            }
            return;
        }),
    ]);
}

const INITIAL_STATE = {
    isAuthenticated: false,
    config: null,
    accessToken: '',
    accessPayload: null,
    idToken: '',
    idPayload: null,
    userInfo: null,
    userInfoLoadedAt: null,
};
class AuthSessionFacade {
    oidc = inject(OidcSecurityService);
    guard = inject(SsoSessionGuardService);
    http = inject(HttpClient);
    events = inject(PublicEventsService);
    router = inject(Router);
    _bootstrapPromise = null;
    _bootstrapped = false;
    subs = [];
    started = false;
    _state$ = new BehaviorSubject(INITIAL_STATE);
    state$ = this._state$.asObservable();
    _logoutRequested$ = new Subject();
    onLogoutRequested$ = this._logoutRequested$.asObservable();
    _pendingReturnUrl = null;
    // útiles, pero la app NO tiene por qué subscribirse
    onLogin$ = this.state$.pipe(map$1(s => s.isAuthenticated), distinctUntilChanged(), pairwise(), filter(([prev, curr]) => !prev && curr), map$1(() => void 0), shareReplay({ bufferSize: 1, refCount: false }));
    onLogout$ = this.state$.pipe(map$1(s => s.isAuthenticated), distinctUntilChanged(), pairwise(), filter(([prev, curr]) => prev && !curr), map$1(() => void 0), shareReplay({ bufferSize: 1, refCount: false }));
    // ✅ state como signal (sincronizado con state$)
    state = toSignal(this.state$, { initialValue: INITIAL_STATE });
    // ✅ selectores simples (signals)
    isAuthenticated = computed(() => !!this.state().isAuthenticated, ...(ngDevMode ? [{ debugName: "isAuthenticated" }] : []));
    config = computed(() => this.state().config, ...(ngDevMode ? [{ debugName: "config" }] : []));
    accessToken = computed(() => this.state().accessToken ?? '', ...(ngDevMode ? [{ debugName: "accessToken" }] : []));
    accessPayload = computed(() => this.state().accessPayload ?? null, ...(ngDevMode ? [{ debugName: "accessPayload" }] : []));
    idToken = computed(() => this.state().idToken ?? '', ...(ngDevMode ? [{ debugName: "idToken" }] : []));
    idPayload = computed(() => this.state().idPayload ?? null, ...(ngDevMode ? [{ debugName: "idPayload" }] : []));
    userInfo = computed(() => this.state().userInfo ?? null, ...(ngDevMode ? [{ debugName: "userInfo" }] : []));
    userInfoLoadedAt = computed(() => this.state().userInfoLoadedAt ?? null, ...(ngDevMode ? [{ debugName: "userInfoLoadedAt" }] : []));
    // ✅ estado interno
    _refreshing = signal(false, ...(ngDevMode ? [{ debugName: "_refreshing" }] : []));
    // ✅ solo lectura para la UI
    refreshing = this._refreshing.asReadonly();
    // ✅ clientLabel derivado (sin lógica en App)
    clientLabel = computed(() => this.computeClientLabelFromState(this.state()), ...(ngDevMode ? [{ debugName: "clientLabel" }] : []));
    checkAuthOnce() {
        return firstValueFrom(this.oidc.checkAuth().pipe(take$1(1))).then(r => !!r.isAuthenticated).catch(() => false);
    }
    bootstrap() {
        if (this.started)
            return;
        this.setupDeepLinkRestore();
        this.started = true;
        const path = window.location.pathname || '';
        // config 1 vez
        this.oidc.getConfiguration().pipe(take$1(1)).subscribe(cfg => {
            this.patchState({ config: cfg });
        });
        // ruta /logout
        if (path.startsWith('/logout')) {
            this.guard.markLogoutFromThisApp();
            this.oidc.logoffLocal();
            this.resetAuthState();
            return;
        }
        // escuchar cambios del oidc
        this.subs.push(this.oidc.isAuthenticated$.subscribe(({ isAuthenticated }) => {
            if (isAuthenticated)
                this.guard.clearLogoutDisabledFlag();
            this.patchState({ isAuthenticated });
            if (isAuthenticated) {
                this.refreshTokens();
                this.tryNavigatePendingReturnUrl(); // ✅ acá
            }
            else {
                this.clearTokensAndUserInfo();
            }
        }));
    }
    bootstrapOnce() {
        if (this._bootstrapped)
            return Promise.resolve();
        if (!this._bootstrapPromise) {
            this._bootstrapPromise = Promise.resolve()
                .then(() => {
                this.bootstrap();
                // /logout: no ping, ya cerramos local
                if (window.location.pathname.startsWith('/logout'))
                    return;
                return this.guard.bootstrapAuthOnce({ doCheckAuth: true });
            })
                .then(() => {
                // ✅ solo si todo salió bien
                this._bootstrapped = true;
            })
                .catch(err => {
                // ✅ permitir retry si falló
                this._bootstrapPromise = null;
                this._bootstrapped = false;
                throw err;
            });
        }
        return this._bootstrapPromise;
    }
    setupDeepLinkRestore() {
        this.subs.push(this.events.registerForEvents().subscribe(e => {
            if (!e)
                return;
            if (e.type === EventTypes.NewAuthenticationResult) {
                const url = this.guard.popReturnUrl(); // consume y borra
                if (!url)
                    return;
                this._pendingReturnUrl = url;
                // si YA está autenticado, navegá ahora
                this.tryNavigatePendingReturnUrl();
            }
            if (e.type === EventTypes.CheckingAuthFinishedWithError) {
                this.guard.popReturnUrl();
                this._pendingReturnUrl = null;
            }
        }));
    }
    tryNavigatePendingReturnUrl() {
        const url = this._pendingReturnUrl;
        if (!url)
            return;
        const isAuth = this._state$.value.isAuthenticated;
        if (!isAuth)
            return;
        this._pendingReturnUrl = null;
        const current = window.location.pathname + window.location.search;
        if (current === url)
            return;
        queueMicrotask(() => {
            this.router
                .navigateByUrl(url, { replaceUrl: true })
                .then(ok => console.log(`[AuthSessionFacade] deep-link navigate ok=${ok} url=${url}`))
                .catch(err => console.error('[AuthSessionFacade] deep-link navigate error', err));
        });
    }
    computeClientLabelFromState(s) {
        const idp = s.idPayload ?? null;
        if (idp?.client_name)
            return String(idp.client_name);
        if (idp?.azp)
            return String(idp.azp);
        const cfg = s.config;
        const clientId = cfg?.clientId ?? cfg?.client_id ?? null;
        return clientId ? String(clientId) : 'No client id';
    }
    // -------------------------
    // ACTIONS
    // -------------------------
    login() {
        // ✅ capturar deep-link ANTES de navegar al IdP
        this.guard.setReturnUrl(window.location.pathname + window.location.search);
        this.oidc.authorize();
    }
    logout() {
        this._logoutRequested$.next();
        // transición local inmediata
        this.resetAuthState();
        this.guard.markLogoutFromThisApp();
        this.oidc.logoff().subscribe();
    }
    refresh() {
        if (this._refreshing()) {
            return of(null); // evita doble refresh
        }
        this._refreshing.set(true);
        return this.oidc.forceRefreshSession().pipe(switchMap(r => {
            this.refreshTokens();
            return of(r);
        }), finalize(() => this._refreshing.set(false)));
    }
    goUserProfile() {
        this.oidc.getConfiguration().pipe(take$1(1)).subscribe(cfg => {
            const authority = cfg.authority;
            const clientId = cfg.clientId;
            const returnUrl = encodeURIComponent(window.location.origin + window.location.pathname);
            window.location.href =
                `${authority}/account/profile?client_id=${clientId}&returnUrl=${returnUrl}`;
        });
    }
    getAccessToken() {
        return this.oidc.getAccessToken();
    }
    // -------------------------
    // LOADERS (STATE “RICO”)
    // -------------------------
    refreshTokens() {
        forkJoin({
            at: this.oidc.getAccessToken().pipe(take$1(1)),
            atp: this.oidc.getPayloadFromAccessToken().pipe(take$1(1)),
            it: this.oidc.getIdToken().pipe(take$1(1)),
            itp: this.oidc.getPayloadFromIdToken().pipe(take$1(1)),
        }).subscribe({
            next: ({ at, atp, it, itp }) => {
                this.patchState({
                    accessToken: at ?? '',
                    accessPayload: atp ?? null,
                    idToken: it ?? '',
                    idPayload: itp ?? null,
                });
            },
            error: _ => { }
        });
    }
    refreshUserInfo() {
        const cur = this._state$.value;
        if (!cur.isAuthenticated || !cur.config?.authority) {
            this.patchState({ userInfo: null, userInfoLoadedAt: null });
            return;
        }
        forkJoin([
            this.oidc.getAccessToken().pipe(take$1(1)),
            this.oidc.getConfiguration().pipe(take$1(1)),
        ])
            .pipe(switchMap(([token, cfg]) => {
            const authority = cfg?.authority ?? '';
            if (!token || !authority)
                return of({ error: 'missing token/authority' });
            const headers = new HttpHeaders({ Authorization: `Bearer ${token}` });
            return this.http.get(`${authority}/connect/userinfo`, { headers }).pipe(catchError(err => of({
                error: err?.message ?? 'UserInfo error',
                status: err?.status,
            })));
        }))
            .subscribe(data => {
            this.patchState({
                userInfo: data ?? null,
                userInfoLoadedAt: new Date(),
            });
        });
    }
    clearUserInfo() {
        this.patchState({ userInfo: null, userInfoLoadedAt: null });
    }
    // -------------------------
    // HELPERS
    // -------------------------
    patchState(p) {
        const cur = this._state$.value;
        this._state$.next({ ...cur, ...p });
    }
    clearTokensAndUserInfo() {
        this.patchState({
            accessToken: '',
            accessPayload: null,
            idToken: '',
            idPayload: null,
            userInfo: null,
            userInfoLoadedAt: null,
        });
    }
    resetAuthState() {
        const cur = this._state$.value;
        this._state$.next({
            ...cur,
            isAuthenticated: false,
            accessToken: '',
            accessPayload: null,
            idToken: '',
            idPayload: null,
            userInfo: null,
            userInfoLoadedAt: null,
        });
    }
    ngOnDestroy() {
        this.subs.forEach(s => s.unsubscribe());
        this.subs = [];
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: AuthSessionFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: AuthSessionFacade, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.4", ngImport: i0, type: AuthSessionFacade, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * Public API Surface of mma-sso-session-guard
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AuthSessionFacade, SSO_SESSION_GUARD_CONFIG, SimpleLogLevel, SsoSessionGuardService, provideSsoSessionGuard };
//# sourceMappingURL=mma-sso-session-guard.mjs.map
